<?php
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "townchat";
$con = mysqli_connect($servername, $username, $password, $dbname) or 
die("Connection failed: " . mysqli_connect_error());
 
if(isset($_POST['but_upload'])){
   
   $maxsize = 2242880;

   if(isset($_POST ['product_name'])){
      $errors= array();
      $product_name =$con -> real_escape_string($_POST ['product_name']);
      $description =$con -> real_escape_string($_POST ['description']);
      $price =$con -> real_escape_string($_POST ['price']);
      $category =$con -> real_escape_string($_POST ['category']);
       $name=$_FILES["file"]["name"];
       $target_dir ="ait_products/";
       $target_file =$target_dir .$_FILES["file"]["name"];
       $extension = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
       $extensions_arr = array("jpeg","jpg","png");

       $permitted_chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $random_stribng = substr(str_shuffle($permitted_chars), 1, 6);
       if( in_array($extension,$extensions_arr) ){
        
             if(($_FILES['file']['size'] >= $maxsize) || ($_FILES["file"]["size"] == 0)) {
              
                $_SESSION['uploadmessage'] = "File too large. File must be less than 2MB.";
           }
          else{
              if(move_uploaded_file($_FILES['file']['tmp_name'],$target_file)){              

              mysqli_query( $con,"INSERT INTO earn_marketplace_products (name,description,price,media,product_id,category) 
              VALUES ('$product_name','$description','$price','$name','$random_stribng','$category')") or die(mysqli_error($con));
               echo "<script type='text/javascript'>alert('Successfully Uploaded')</script>";
              }
         }
       }else{
          $_SESSION['uploadmessage'] = "Invalid file extension.";
       }
   }else{
       $_SESSION['uploadmessage'] = "Please select a file.";
       print_r($_FILES);
   }
}

?>


<!DOCTYPE html>
<html>
   <meta name="viewport" content="width=device-width, initial-scale=1.0" />
   <title>Upload Products</title>
   <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet" />
   <link rel="stylesheet" href="css/materialize.css" />
   <link rel="stylesheet" href="css/materialize.min.css" />
   <link rel="stylesheet" href="css/business_register.css" />
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous" />
   <body>
      <form id="regForm" action="" method="POST" enctype="multipart/form-data">
         <h4>Upload Products</h4>
         <!-- One "tab" for each step in the form: -->
         <div class="tab">
            <div class="input-field col s12">
               <input id="product_name" name="product_name" type="text" class="validate" />
               <label for="product_name">Product Name</label>
            </div>
            <div class="input-field col s12">
               <input id="description" name="description" type="text" class="validate" />
               <label for="description">Description</label>
            </div>
            <div class="input-field col s12">
               <input id="price" type="number" name="price" class="validate" />
               <label for="price">Price (In Town Coins)</label>
            </div>
            <div class="input-field col s12">
            <select class="form-select" name="category" aria-label="Default select example">
                    <option selected>Select Category</option>
                    <option value="Auto & Vehicles">Auto & Vehicles</option>
                    <option value="Baby & Children's Products">Baby & Children's Products</option>
                    <option value="Beauty Products & Services">Beauty Products & Services</option>
                    <option value="Computers & Peripherals">Computers & Peripherals</option>
                    <option value="Consumer Electronics">Consumer Electronics</option>
                    <option value="Financial Services">Financial Services</option>
                    <option value="Gifts & Occasions">Gifts & Occasions</option>
                    <option value="Home & Garden">Home & Garden</option>
                    <option value="Home appliances">Home appliances</option>
                </select>
            </div>
            <div class="file-field input-field">
               <div class="btn card-panel teal lighten-2">
                  <span class="white-text">Product Image</span>
                  <input type='file' name='file' />
               </div>
               <div class="file-path-wrapper">
                  <input class="file-path " placeholder="upload your image" type="text" />
               </div>
               <div style="float: right">
                    <button type="submit" name="but_upload" class="teal">SUBMIT</button>
                </div>
            </div>

         </div>

         
         <?php 
            if(isset($_SESSION['uploadmessage'])){
            echo $_SESSION['uploadmessage'];
            unset($_SESSION['uploadmessage']);
            }
            ?>
         <!-- <div style="overflow: auto;padding:10px 10px 15px 10px;">
            <div style="">
               <button type="button" style="float:left;" id="prevBtn" class="btn bg-light btn-small" onclick="nextPrev(-1)"><i class="fa-solid fa-chevron-left"></i></button>
               <button type="button" style="float: right;" class="btn btn-primary btn-small" id="nextBtn" onclick="nextPrev(1)">Next</button>
            </div>
         </div> -->
         <!-- Circles which indicates the steps of the form: -->
         <div style="text-align: center; margin-top: 10px; display:none">
            <span class="step"></span>
            <span class="step"></span>
         </div>
      </form>

      <script src="https://kit.fontawesome.com/46462c3eb9.js" crossorigin="anonymous"></script>
      <script src="js/materialize.js"></script>
      <script src="js/materialize.min.js"></script>
      <script src="js/business_register.js"></script>
      <script src="js/product_upload.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
   </body>
</html>
