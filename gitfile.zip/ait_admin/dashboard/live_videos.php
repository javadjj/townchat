<?php 
include('header.php');
include('db.php');
if(isset($_SESSION['ROLE'])){
	if($_SESSION['ROLE'] == 3 || $_SESSION['ROLE'] == 2){
		header('location:index.php');
		die();;
	}
}
//APPROVE SYSYTEM
if (isset($_GET['approve']))
{
    $id = $_GET['approve'];
    mysqli_query($con, "UPDATE earn_bss_rgstr SET admin_status='approved' WHERE Ad_id='$id'") or die(mysqli_error($con));
    $_SESSION['msg'] = "Ad Approved!";
}

if (isset($_GET['reject']))
{
    $id = $_GET['reject'];

	mysqli_query($con, "DELETE FROM earn_bss_rgstr WHERE Ad_id=$id");
	$_SESSION['msg'] = "Ad deleted!";
	//header('location: ait_videdo_requests.php');
}

?>		 
<div class="container-fluid">
   <!-- DataTables Example -->
   <div class="card mb-3">
	  <div class="card-header">
      <i class="fa fa-video-camera" aria-hidden="true"></i>
		<h3>Live Videos</h3>
	  </div>
	  <div class="card-body">
		 <!-- <div class="table-responsive"> -->
			<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
			<!-- <div class="row"> -->
            
							<?php
						$sql = "SELECT * FROM earn_bss_rgstr WHERE admin_status='approved' ORDER BY Ad_id";
						$result = $con->query($sql);
						if ($result->num_rows > 0) {
					  	while($row = $result->fetch_assoc()) {
					?>
					<div class="row my-md-5 mx-md-5 border video-card rounded">
                        <div class="col col-12 col-sm-6 float-left my-3 mx-3">	
            	            <div class="">
	                        <p>Business Name: <strong><?php echo $row['businessName']; ?></strong> </p>
			                <p>Budjet: ₹<strong><?php echo $row['budjet']; ?></strong> </p>
                            <hr>
                            <div class="row">
                            <small>Question one:</small>
                            <p><strong><?php echo $row['question1']; ?></strong></p>
                            <div class="col col-12">
                                <small>Right Answer:</small>
                                <p><strong><?php echo $row['question1_answer']; ?></strong></p>
                            </div>
                            <div class="col col-sm-6">
                                <small>Option one:</small>
                                <p><strong><?php echo $row['question1_option1']; ?></strong></p>
                            </div>
                            <div class="col col-sm-6">
                                <small>Option two:</small>
                                <p><strong><?php echo $row['question1_option2']; ?></strong></p>
                            </div>
                            </div>
                            <div class="row">
                            <small>Question Two:</small>
                            <p><strong><?php echo $row['question2']; ?></strong></p>
                            <div class="col col-12">
                                <small>Right Answer:</small>
                                <p><strong><?php echo $row['question2_answer']; ?></strong></p>
                            </div>
                            <div class="col col-sm-6">
                                <small>Option one:</small>
                                <p><strong><?php echo $row['question2_option1']; ?></strong></p>
                            </div>
                            <div class="col col-sm-6">
                                <small>Option two:</small>
                                <p><strong><?php echo $row['question2_option2']; ?></strong></p>
                            </div>
                            </div>
                            <div class="">
                            <a href="live_videos.php?suspent=<?php echo $row['Ad_id']; ?>" class="btn btn-warning" name="suspent">Suspend</a>
                            <a href="edit_video.php?id=<?php echo $row['Ad_id']; ?>" class="btn btn-dark text-white" name="edit">Edit</a>
                            <a href="live_videos.php?reject=<?php echo $row['Ad_id']; ?>" class="btn btn-danger text-white">Reject</a>

							<!-- <button id="myBtn">Open Modal</button> -->
                            </div>
                        </div>
					</div>
                     <div class="col col-12 col-sm-4 content">
	                    <video class="media-video " src="../ait_videos/<?php echo $row['name']; ?>" alt="" controls></video>

                    </div>
				</div>
					<?php
							}
						}
				  	?>
			</table>

<!-- /.container-fluid -->
<?php include('footer.php')?>
