<?php 
include('header.php');
include('db.php');
// if(isset($_SESSION['ROLE']) && $_SESSION['ROLE']!='1'){
// 	header('location:news.php');
// 	die();
// }
?>
<div class="container-fluid">
<ol class="breadcrumb">
  <li class="breadcrumb-item">
	 <a href="">Dashboard</a>
  </li>
</ol>
<!-- Page Content -->
<hr>
<h1 class="float-left">Hi <?php echo $_SESSION['NAME'] ?>,Welcome To AIT </h1>
<hr>
</div>
<?php include('footer.php')?>