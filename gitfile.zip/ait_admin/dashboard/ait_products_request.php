<?php 
include('header.php');
include('db.php');
if(isset($_SESSION['ROLE'])){
	if($_SESSION['ROLE'] == 3 || $_SESSION['ROLE'] == 2){
		header('location:index.php');
		die();;
	}
}
//APPROVE SYSYTEM
if (isset($_GET['approve']))
{
    $id = $_GET['approve'];
    mysqli_query($con, "UPDATE earn_marketplace_products SET admin_status='approved' WHERE id='$id'") or die(mysqli_error($con));
    $_SESSION['msg'] = "Ad Approved!";
}

if (isset($_GET['reject']))
{
    $id = $_GET['reject'];

	mysqli_query($con, "DELETE FROM earn_marketplace_products WHERE id=$id");
	$_SESSION['msg'] = "Ad deleted!";
	//header('location: ait_videdo_requests.php');
}

?>		 
<div class="container-fluid">
   <!-- DataTables Example -->
   <div class="card mb-3">
	  <div class="card-header">
	  <i class="fa fa-list " aria-hidden="true"></i>
		<h3>Product Requests</h3> 
	  </div>
	  <div class="card-body">
		 <div class="table-responsive">
			<div class="row justify-content-evenly">
		 <?php
			$sql = "SELECT * FROM earn_marketplace_products WHERE admin_status ='not_approved' ORDER BY id";
			$result = $con->query($sql);
			if ($result->num_rows > 0) {
				while($row = $result->fetch_assoc()) {
		?>
	
		<!-- <div class=" "> -->
		 	<div class="card col col-sm-4 float-left my-3 mx-3" style="width: 18rem;">
			 	<p>Uploaded Person: <?php echo $_SESSION['NAME']; ?></p>
  				<img src="../ait_products/earphone.jpg" class="card-img-top" alt="...">
				<hr>
  				<div class="card-body pro-body">
    				<p class="">Product Name: <strong><?php echo $row['name']; ?></strong></p>
					<p class="">Product ID: <strong><?php echo $row['product_id']; ?></strong></p>
    				<p class="card-text">Description: <br><strong><?php echo $row['description']; ?></strong></p>
    				<p class="">Price: <strong><?php echo $row['price']; ?></strong></p>
					<p class="">Category: <strong><?php echo $row['category']; ?></strong></p>
					<div class="row">
						<div class="col-4">
							<a href="ait_products_request.php?approve=<?php echo $row['id']; ?>" class="btn "><i class="fa fa-check text-success" aria-hidden="true"></i></a>
						</div>
						<div class="col-4">
							<a href="edit_product.php?id=<?php echo $row['id']; ?>" class="btn " name="edit"><i class="fa fa-pencil text-warning" aria-hidden="true"></i></a>
						</div>
						<div class="col-4">
							<a href="ait_products_request.php?reject=<?php echo $row['id']; ?>" class="btn "><i class="fa fa-trash-o text-danger" aria-hidden="true"></i></a>
						</div>
					</div>
				</div>
			</div>
			<?php
					}
				}
			?>
		 <!-- </div> -->
		</div>
		</div>
	  </div>
   </div>
</div>
<!-- /.container-fluid -->
<?php include('footer.php')?>