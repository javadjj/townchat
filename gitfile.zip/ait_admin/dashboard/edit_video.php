<?php
include('header.php');
include_once("db.php");
if(isset($_SESSION['ROLE'])){
	if($_SESSION['ROLE'] == 3 || $_SESSION['ROLE'] == 2){
		header('location:index.php');
		die();;
	}
}
if(isset($_POST['update'])){   
    $id = $_POST['id'];
    
    $name=$_POST['businessname'];
    $budjet=$_POST['budjet'];
    $question1=$_POST['question1']; 
    $question1_answer=$_POST['question1_answer'];
    $question1_option1=$_POST['question1_option1'];
    $question1_option2=$_POST['question1_option2']; 
    $question2=$_POST['question2']; 
    $question2_answer=$_POST['question2_answer'];
    $question2_option1=$_POST['question2_option1'];
    $question2_option2=$_POST['question2_option2']; 
    
    // checking empty fields
    if(empty($name) || empty($budjet) || empty($question1)) {          
        if(empty($name)) {
            echo "<font color='red'>Business name field is empty.</font><br/>";
        }
        
        if(empty($budjet)) {
            echo "<font color='red'>Budjet field is empty.</font><br/>";
        }
        
        if(empty($question1)) {
            echo "<font color='red'>Question one field is empty.</font><br/>";
        }       
    } else {    
        //updating the table
        $result = mysqli_query($con, "UPDATE earn_bss_rgstr SET businessName='$name',budjet='$budjet', question1='$question1', question1_answer='$question1_answer', question1_option1=' $question1_option1',
        question1_option2=' $question1_option2', question2='$question2', question2_answer='$question2_answer', question2_option1='$question2_option1', question2_option2='$question2_option2' WHERE Ad_id=$id");
        
        //redirectig to the display page. In our case, it is index.php
        //header("Location: ait_video_requests.php");
        echo("<script>location.href = ' live_videos_requests.php?msg=';</script>");
    }
}

//getting id from url
$id = $_GET['id'];

//selecting data associated with this particular id
$result = mysqli_query($con, "SELECT * FROM earn_bss_rgstr WHERE Ad_id=$id");

while($res = mysqli_fetch_array($result))
{
    $businessname = $res['businessName'];
    $businessbudjet = $res['budjet'];
    $B_question1=$res['question1']; 
    $B_question1_answer=$res['question1_answer'];
    $B_question1_option1=$res['question1_option1'];
    $B_question1_option2=$res['question1_option2']; 
    $B_question2=$res['question2']; 
    $B_question2_answer=$res['question2_answer'];
    $B_question2_option1=$res['question2_option1'];
    $B_question2_option2=$res['question2_option2'];
    $ad_id=$res['Ad_id']; 
}
?>

<div class="container-fluid">
   <!-- DataTables Example -->
   <div class="card mb-3">
	  <div class="card-header">
     <i class="fa fa-pencil" aria-hidden="true"></i>
		<h3>Edit Video Details</h3> 
	  </div>
	  <div class="card-body">
		 <div class="table-responsive">
        <div class="edit-form-wrapper">
         <form id="regForm" class="edit-form rounded" action="" method="POST" enctype="multipart/form-data">
         <h4>Edit</h4>
         <!-- One "tab" for each step in the form: -->
         <div class="tab">
            <div class="input-field col s12">
               <input id="business_name" name="businessname" value="<?php echo $businessname;?>" type="text" class="validate" />
               <label for="business_name">Business Name</label>
            </div>
            <div class="input-field col s12">
               <input id="budjet" type="number" name="budjet" value="<?php echo $businessbudjet;?>" class="validate" />
               <label for="budjet">Budjet</label>
            </div>
            <!-- <div class="row">
               <div class="input-field col s6">
                  <input id="latitude" type="text" name="latitude" class="validate" />
                  <label for="latitude">Latitude</label>
               </div>
               <div class="input-field col s6">
                  <input id="longitude" type="text" name="longitude" class="validate" />
                  <label for="longitude">Longitude</label>
               </div>
            </div> -->
         </div>
         <div class="">
            Video Related Question 1
            <div class="input-field col s12">
               <input id="question_1" type="text" name="question1" value="<?php echo $B_question1;?>" class="validate" />
               <label for="question_1">Question One</label>
            </div>
            <div class="input-field col s12">
               <input id="right_answer1" type="text" name="question1_answer" value="<?php echo $B_question1_answer;?>" class="validate" />
               <label for="right_answer1">Right Answer</label>
            </div>
            <div class="row">
               <div class="input-field col s6">
                  <input id="q_1option_1" type="text" name="question1_option1" value="<?php echo $B_question1_option1;?>" class="validate" />
                  <label for="q_1option_1">Option 1</label>
               </div>
               <div class="input-field col s6">
                  <input id="q_1option_2" type="text" name="question1_option2" value="<?php echo $B_question1_option2;?>" class="validate" />
                  <label for="q_1option_2">ption 2</label>
               </div>
            </div>
         </div>
         <div class="">
            Video Related Question 2
            <div class="input-field col s12">
               <input id="question_2" type="text"  name="question2" value="<?php echo $B_question2;?>" class="validate" />
               <label for="question_2">Question Two</label>
            </div>
            <div class="input-field col s12">
               <input id="right_answer2" type="text" name="question2_answer" value="<?php echo $B_question2_answer;?>" class="validate" />
               <label for="right_answer2">Right Answer</label>
            </div>
            <div class="row">
               <div class="input-field col s6">
                  <input id="q_2option_1" type="text" name="question2_option1" value="<?php echo $B_question2_option1;?>" class="validate" />
                  <label for="q_2option_1">Option 1</label>
               </div>
               <div class="input-field col s6">
                  <input id="q_2option_2" type="text" name="question2_option2" value="<?php echo $B_question2_option2;?>" class="validate" />
                  <input type="hidden" name="id" value=<?php echo $ad_id;?>>
                  <label for="q_2option_2">ption 2</label>
               </div>
               <button type="submit" name="update" class="btn btn-primary" >SAVE</button>
            </div>
         </div>
      </form>
    </div>
      </div>
		 </div>
	  </div>
   </div>
</div>
<!-- /.container-fluid -->
<?php include('footer.php')?>