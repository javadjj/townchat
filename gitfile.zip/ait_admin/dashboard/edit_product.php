<?php

include('header.php');
include_once("db.php");
if(isset($_SESSION['ROLE'])){
	if($_SESSION['ROLE'] == 3 || $_SESSION['ROLE'] == 2){
		header('location:index.php');
		die();;
	}
}

if(isset($_POST['update'])){   
    $id = $_POST['id'];
    
    $ait_name = $_POST['name'];
    $ait_description=$_POST['description']; 
    $ait_price=$_POST['price'];
    $ait_category=$_POST['category'];
    
    // checking empty fields
    if(empty($ait_name) || empty($ait_description) || empty($ait_price) || empty($ait_category)) {          
        if(empty($ait_name)) {
            echo "<font color='red'>Business name field is empty.</font><br/>";
        }
        
        if(empty($ait_description)) {
            echo "<font color='red'>Budjet field is empty.</font><br/>";
        }
        
        if(empty($ait_price)) {
            echo "<font color='red'>Question one field is empty.</font><br/>";
        }   
        if(empty($ait_category)) {
            echo "<font color='red'>Question one field is empty.</font><br/>";
        }     
    } else {    
        //updating the table
        $result = mysqli_query($con, "UPDATE earn_marketplace_products SET name='$ait_name',description='$ait_description', price='$ait_price', category='$ait_category' WHERE id=$id");
        
        //redirectig to the display page. In our case, it is index.php
       // header("Location: ait_products_request.php");
        echo("<script>location.href = 'ait_products_request.php?msg=';</script>");
    }
}

//getting id from url
$id = $_GET['id'];

//selecting data associated with this particular id
$result = mysqli_query($con, "SELECT * FROM earn_marketplace_products WHERE id=$id");

while($res = mysqli_fetch_array($result))
{
    $product_id = $res['product_id'];
    $name = $res['name'];
    $description=$res['description']; 
    $price=$res['price'];
    $category=$res['category'];
    $id=$res['id']; 
}
?>

<div class="container-fluid">
   <!-- DataTables Example -->
   <div class="card mb-3">
	  <div class="card-header">
      <i class="fa fa-pencil" aria-hidden="true"></i>
		<h3>Edit Product Details</h3> 
	  </div>
	  <div class="card-body">
		 <div class="table-responsive">
        <div class="edit-form-wrapper">
         <form id="regForm" class="edit-form rounded" action="" method="POST" enctype="multipart/form-data">
         <h4>Edit</h4>
         <!-- One "tab" for each step in the form: -->
         <div class="tab">
            <div class="input-field col s12">
               <input id="business_name" name="name" value="<?php echo $name;?>" type="text" class="validate" />
               <label for="business_name">Product Name</label>
            </div>
            <div class="input-field col s12">
               <input id="budjet" type="text" name="description" value="<?php echo $description;?>" class="validate" />
               <label for="budjet">Description</label>
            </div>
         </div>
         <div class="">
            <div class="input-field col s12">
               <input id="question_1" type="text" name="price" value="<?php echo $price;?>" class="validate" />
               <label for="question_1">Price</label>
            </div>
            <div class="input-field col s12">
               <input id="right_answer1" type="text" name="category" value="<?php echo $category;?>" class="validate" />
               <label for="right_answer1">Category</label>
            </div>
            <div class="input-field col s12">
            <select class="form-select" name="category" value="<?php echo $category;?>" >
                    <option selected>Select Category</option>
                    <option value="Auto & Vehicles">Auto & Vehicles</option>
                    <option value="Baby & Children's Products">Baby & Children's Products</option>
                    <option value="Beauty Products & Services">Beauty Products & Services</option>
                    <option value="Computers & Peripherals">Computers & Peripherals</option>
                    <option value="Consumer Electronics">Consumer Electronics</option>
                    <option value="Financial Services">Financial Services</option>
                    <option value="Gifts & Occasions">Gifts & Occasions</option>
                    <option value="Home & Garden">Home & Garden</option>
                    <option value="Home appliances">Home appliances</option>
                </select>
            </div>
            <input type="hidden" name="id" value=<?php echo $id;?>>
            <button type="submit" name="update" class="btn btn-primary" >SAVE</button>
         </div>
      </form>
    </div>
      </div>
		 </div>
	  </div>
   </div>
</div>
<!-- /.container-fluid -->
<?php include('footer.php')?>