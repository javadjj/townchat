<?php
// including the database connection file
include_once("db.php");

if(isset($_POST['update']))
{   
    $id = $_POST['id'];
    
    $name=$_POST['businessname'];
    $budjet=$_POST['budjet'];
    $question1=$_POST['question1']; 
    $question1_answer=$_POST['question1_answer'];
    $question1_option1=$_POST['question1_option1'];
    $question1_option2=$_POST['question1_option2']; 
    $question2=$_POST['question2']; 
    $question2_answer=$_POST['question2_answer'];
    $question2_option1=$_POST['question2_option1'];
    $question2_option2=$_POST['question2_option2']; 
    
    // checking empty fields
    if(empty($name) || empty($budjet) || empty($question1)) {          
        if(empty($name)) {
            echo "<font color='red'>Business name field is empty.</font><br/>";
        }
        
        if(empty($budjet)) {
            echo "<font color='red'>Budjet field is empty.</font><br/>";
        }
        
        if(empty($question1)) {
            echo "<font color='red'>Question one field is empty.</font><br/>";
        }       
    } else {    
        //updating the table
        $result = mysqli_query($con, "UPDATE earn_bss_rgstr SET businessName='$name',budjet='$budjet', question1='$question1', question1_answer='$question1_answer', question1_option1=' $question1_option1',
        question1_option2=' $question1_option2', question2='$question2', question2_answer='$question2_answer', question2_option1='$question2_option1', question2_option2='$question2_option2' WHERE Ad_id=$id");
        
        //redirectig to the display page. In our case, it is index.php
        header("Location: ait_video_requests.php");
    }
}
?>
<?php
//getting id from url
$id = $_GET['id'];

//selecting data associated with this particular id
$result = mysqli_query($con, "SELECT * FROM earn_bss_rgstr WHERE Ad_id=$id");

while($res = mysqli_fetch_array($result))
{
    $businessname = $res['businessName'];
    $businessbudjet = $res['budjet'];
    $B_question1=$res['question1']; 
    $B_question1_answer=$res['question1_answer'];
    $B_question1_option1=$res['question1_option1'];
    $B_question1_option2=$res['question1_option2']; 
    $B_question2=$res['question2']; 
    $B_question2_answer=$res['question2_answer'];
    $B_question2_option1=$res['question2_option1'];
    $B_question2_option2=$res['question2_option2'];
    $ad_id=$res['Ad_id']; 
}
?>
<html>
<head>  
    <title>Edit Data</title>
</head>

<body>
    <a href="index.php">Home</a>
    <br/><br/>
    
    <form name="form1" method="post" action="">
        <table border="0">
            <tr> 
                <td>Business Name</td>
                <td><input type="text" name="businessname" value="<?php echo $businessname;?>"></td>
            </tr>
            <tr> 
                <td>Budjet</td>
                <td><input type="text" name="budjet" value="<?php echo $businessbudjet;?>"></td>
            </tr>
            <tr> 
                <td>Question One</td>
                <td><input type="text" name="question1" value="<?php echo $B_question1;?>"></td>
            </tr>
            <tr> 
                <td>Right Answer</td>
                <td><input type="text" name="question1_answer" value="<?php echo $B_question1_answer;?>"></td>
            </tr>
            <tr> 
                <td>Option One</td>
                <td><input type="text" name="question1_option1" value="<?php echo $B_question1_option1;?>"></td>
            </tr>
            <tr> 
                <td>Option Two</td>
                <td><input type="text" name="question1_option2" value="<?php echo $B_question1_option2;?>"></td>
            </tr>
            <tr> 
                <td>Question Two</td>
                <td><input type="text" name="question2" value="<?php echo $B_question2;?>"></td>
            </tr>
            <tr> 
                <td>Right Answer</td>
                <td><input type="text" name="question2_answer" value="<?php echo $B_question2_answer;?>"></td>
            </tr>
            <tr> 
                <td>Option One</td>
                <td><input type="text" name="question2_option1" value="<?php echo $B_question2_option1;?>"></td>
            </tr>
            <tr> 
                <td>Option Two</td>
                <td><input type="text" name="question2_option2" value="<?php echo $B_question2_option2;?>"></td>
            </tr>
            <tr>
                <td><input type="hidden" name="id" value=<?php echo $ad_id;?>></td>
                <td><input type="submit" name="update" value="Update"></td>
            </tr>
        </table>
    </form>
</body>
</html>