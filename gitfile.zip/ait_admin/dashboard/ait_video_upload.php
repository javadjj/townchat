<?php 
include('header.php');
include_once('db.php');
if(isset($_SESSION['ROLE'])){
	if($_SESSION['ROLE'] == 2){
		header('location:index.php');
		die();;
	}
}
if(isset($_POST['but_upload'])){
	$maxsize = 5242880;
	if(isset($_POST ['businessname'])){
	   $errors= array();
      $from_who =$_SESSION['NAME'];
	   $businessName =$_POST ['businessname'];
	   $whatsapp_number = $_POST['whatsapp_number'];
		$budjet =$_POST ['budjet'];
	   $latitude =$_POST ['latitude'];
	   $longitude =$_POST ['longitude'];
	   $question1 =$con -> real_escape_string($_POST ['question1']);
	   $question1answer =$con -> real_escape_string($_POST ['question1answer']);
	   $question1_option1 =$_POST ['question1_option1'];
	   $question1_option2 =$_POST ['question1_option2'];
	   $question2 =$con -> real_escape_string($_POST ['question2']);
	   $question2_answer = $_POST['question2_answer'];
	   $question2_option1 = $_POST['question2_option1'];
	   $question2_option2 = $_POST['question2_option2'];
		$name=$_FILES["file"]["name"];
		$target_dir ="../ait_videos/";
		$target_file =$target_dir .$_FILES["file"]["name"];
		$extension = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
		$extensions_arr = array("mp4");
      
                 // checking empty fields
    if(empty($businessName) || empty($whatsapp_number) || empty($budjet) || empty($latitude) || empty($longitude) || empty($question1) || empty($question1answer)
    || empty($question1_option1) || empty($question1_option2) || empty($question2) || empty($question2_answer) || empty($question2_option1) || empty($question2_option2) || empty($from_who)) {          
   
      $_SESSION['videouploadmessage']= "<font color='red'>One or more fields are empty.</font><br/>";
   }else{
		if( in_array($extension,$extensions_arr) ){
		
			  if(($_FILES['file']['size'] >= $maxsize) || ($_FILES["file"]["size"] == 0)) {
			   
				 $_SESSION['videouploadmessage'] = "<font color='red'>File too large. File must be less than 2MB. </font><br/>";
			}
		   else{
			   if(move_uploaded_file($_FILES['file']['tmp_name'],$target_file)){              
 
			   mysqli_query( $con,"INSERT INTO earn_bss_rgstr (businessName,phone,budjet,question1,question1_answer,question1_option1,question1_option2,question2,question2_answer,question2_option1,question2_option2,name,video_url,latitude,longitude,uploded_person) 
			   VALUES ('$businessName','$whatsapp_number','$budjet','$question1','$question1answer','$question1_option1','$question1_option2','$question2','$question2_answer','$question2_option1','$question2_option2','$name','$target_file','$latitude','$longitude','$from_who')") or die(mysqli_error($con));
			   echo "<script type='text/javascript'>alert('Successfully Registered')</script>";
			   }
		  }
		}else{
		   $_SESSION['videouploadmessage'] = "<font color='red'>Invalid file extension.</font><br/>";
		}
   }
	}else{
		$_SESSION['videouploadmessage'] = "<font color='red'>Please select a file.</font><br/>";
		print_r($_FILES);
	}
 }
 
?>		 
<div class="container-fluid">
   <!-- DataTables Example -->
   <div class="card mb-3">
	  <div class="card-header">
     <i class="fa fa-upload " aria-hidden="true"></i>
		<h3>Video Upload</h3> 
	  </div>
	  <div class="card-body">
		 <div class="table-responsive">
		 <form id="" action="" method="POST" enctype="multipart/form-data">
		 <?php 
            if(isset($_SESSION['videouploadmessage'])){
            echo $_SESSION['videouploadmessage'];
            unset($_SESSION['videouploadmessage']);
            }
            ?>
         <h4>Register Your Business</h4>
         <!-- One "tab" for each step in the form: -->
         <div class="tab">
            <div class="input-field col s12">
               <input id="business_name" name="businessname" type="text" class="validate" />
               <label for="business_name">Business Name</label>
            </div>
            <div class="input-field col s12">
               <input id="whatsappnumber" value="91" name="whatsapp_number" type="tel" minlength="12" data-length="12" class="validate" />
               <label for="whatsappnumber">WhatsApp Number</label>
            </div>
            <div class="input-field col s12">
               <input id="budjet" type="number" name="budjet" class="validate" />
               
               <label for="budjet">Budjet</label>
            </div>
            <div class="row">
               <div class="input-field col s6">
                  <input id="latitude" type="text" name="latitude" class="validate" />
                  <label for="latitude">Latitude</label>
               </div>
               <div class="input-field col s6">
                  <input id="longitude" type="text" name="longitude" class="validate" />
                  <label for="longitude">Longitude</label>
               </div>
            </div>
            <div class="file-field input-field">
               <div class="btn card-panel teal lighten-2">
                  <span class="white-text">Video</span>
                  <input type='file' name='file' />
               </div>
               <div class="file-path-wrapper">
                  <input class="file-path " placeholder="upload your video" type="text" />
               </div>
            </div>
         </div>
         <div class="">
            Video Related Question 1
            <div class="input-field col s12">
               <input id="question_1" type="text" name="question1" class="validate" />
               <label for="question_1">Question One</label>
            </div>
            <div class="input-field col s12">
               <input id="right_answer1" type="text" name="question1answer" class="validate" />
               <label for="right_answer1">Right Answer</label>
            </div>
            <div class="row">
               <div class="input-field col s6">
                  <input id="q_1option_1" type="text" name="question1_option1" class="validate" />
                  <label for="q_1option_1">Option 1</label>
               </div>
               <div class="input-field col s6">
                  <input id="q_1option_2" type="text" name="question1_option2" class="validate" />
                  <label for="q_1option_2">ption 2</label>
               </div>
            </div>
         </div>
         <div class="">
            Video Related Question 2
            <div class="input-field col s12">
               <input id="question_2" type="text" name="question2" class="validate" />
               <label for="question_2">Question Two</label>
            </div>
            <div class="input-field col s12">
               <input id="right_answer2" type="text" name="question2_answer" class="validate" />
               <label for="right_answer2">Right Answer</label>
            </div>
            <div class="row">
               <div class="input-field col s6">
                  <input id="q_2option_1" type="text" name="question2_option1" class="validate" />
                  <label for="q_2option_1">Option 1</label>
               </div>
               <div class="input-field col s6">
                  <input id="q_2option_2" type="text" name="question2_option2" class="validate" />
                  <label for="q_2option_2">ption 2</label>
               </div>
			   <div>
               <button type="submit" name="but_upload" class="btn btn-primary float-right" >SUBMIT</button>
			   </div>
            </div>
         </div>
      </form>
		 </div>
	  </div>
   </div>
</div>
<!-- /.container-fluid -->
<?php include('footer.php')?>