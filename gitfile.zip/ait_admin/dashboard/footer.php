<!-- Sticky Footer -->
            <footer class="sticky-footer rounded">
               <div class="container my-auto">
                  <div class="copyright text-center my-auto">
                     <!-- <span>Copyright © Your Website 2019</span> -->
                  </div>
               </div>
            </footer>
         </div>
         <!-- /.content-wrapper -->
      </div>
      <!-- /#wrapper -->
      <!-- Scroll to Top Button-->
      <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
      </a>
      <script src="vendor/jquery/jquery.min.js"></script>
      <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
      <!-- Core plugin JavaScript-->
      <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
      <!-- Custom scripts for all pages-->
      <script src="js/sb-admin.min.js"></script>
      <script src="js/sb-admin.js"></script>
      <script src="js/my-js.js"></script>
      <script src="js/materialize.js"></script>
      <script src="js/materialize.min.js"></script>
      <script src="js/business_register.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
      <script>

   document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('#modall');
    var instances = M.Modal.init(elems, options);
  });


      </script>
   </body>
</html>