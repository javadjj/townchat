<?php 
include('header.php');
include_once('db.php');
if(isset($_SESSION['ROLE'])){
	if($_SESSION['ROLE'] == 3){
		header('location:index.php');
		die();;
	}
}
if(isset($_POST['but_upload'])){
   
	$maxsize = 2242880;
 
	if(isset($_POST ['product_name'])){
	   $errors= array();
	   $product_name =$con -> real_escape_string($_POST ['product_name']);
	   $description =$con -> real_escape_string($_POST ['description']);
	   $price =$con -> real_escape_string($_POST ['price']);
	   $category =$con -> real_escape_string($_POST ['category']);
      $from_who = $_SESSION['NAME'];
		$name=$con -> real_escape_string($_FILES["file"]["name"]);
		$target_dir ="../ait_products/";
		$target_file =$target_dir .$_FILES["file"]["name"];
		$extension = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
		$extensions_arr = array("jpeg","jpg","png");
 
		$permitted_chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
		 $random_stribng = substr(str_shuffle($permitted_chars), 1, 6);

           // checking empty fields
    if(empty($product_name) || empty($description) || empty($price) || empty($category) || empty($from_who)) {          
   
      $_SESSION['uploadmessage']= "<font color='red'>One or more fields are empty.</font><br/>";
   }else{
		if( in_array($extension,$extensions_arr) ){
		 
			  if(($_FILES['file']['size'] >= $maxsize) || ($_FILES["file"]["size"] == 0)) {
			   
				 $_SESSION['uploadmessage'] = "<font color='red'>File too large. File must be less than 2MB. </font><br/>";
             
			}else{
			   if(move_uploaded_file($_FILES['file']['tmp_name'],$target_file)){              
 
			   mysqli_query( $con,"INSERT INTO earn_marketplace_products (name,description,price,media,product_id,category,who_uploaded) 
			   VALUES ('$product_name','$description','$price','$name','$random_stribng','$category','$from_who')") or die(mysqli_error($con));
				echo "<script type='text/javascript'>alert('Successfully Uploaded')</script>";
			   }
		  }
		}else{
		   $_SESSION['uploadmessage'] = "<font color='red'>Invalid file extension.</font><br/>";
		}
   }
	}else{
		$_SESSION['uploadmessage'] = "<font color='red'>Please select a file.</font><br/>";
		print_r($_FILES);
	}
 }
 
?>		 
<div class="container-fluid">
   <!-- DataTables Example -->
   <div class="card mb-3">
	  <div class="card-header">
     <i class="fa fa-upload " aria-hidden="true"></i>
		<h3>Product Upload</h3>
	  </div>
	  <div class="card-body">
		 <div class="table-responsive">
		 <form id="" action="" method="POST" class="mb-5" enctype="multipart/form-data">
         <h4>Upload Products</h4>
         <!-- One "tab" for each step in the form: -->
         <?php 
            if(isset($_SESSION['uploadmessage'])){
            echo $_SESSION['uploadmessage'];
            unset($_SESSION['uploadmessage']);
            }
            ?>
         <div class="tab">
            <div class="input-field col s12">
               <input id="product_name" name="product_name" type="text" class="validate" requere/>
               <label for="product_name">Product Name</label>
            </div>
            <div class="input-field col s12">
               <input id="description" name="description" type="text" class="validate" requere/>
               <label for="description">Description</label>
            </div>
            <div class="input-field col s12">
               <input id="price" type="number" name="price" class="validate" requere/>
               <label for="price">Price (In Town Coins)</label>
            </div>
            <div class="input-field col s12">
                <select class="form-select" name="category" aria-label="Default select example"  requere>
                    <option selected>Select Category</option>
                    <option value="Auto & Vehicles">Auto & Vehicles</option>
                    <option value="Baby & Children's Products">Baby & Children's Products</option>
                    <option value="Beauty Products & Services">Beauty Products & Services</option>
                    <option value="Computers & Peripherals">Computers & Peripherals</option>
                    <option value="Consumer Electronics">Consumer Electronics</option>
                    <option value="Financial Services">Financial Services</option>
                    <option value="Gifts & Occasions">Gifts & Occasions</option>
                    <option value="Home & Garden">Home & Garden</option>
                    <option value="Home appliances">Home appliances</option>
                </select>
            </div>
            <div class="file-field input-field">
               <div class="btn card-panel teal lighten-2">
                  <span class="white-text">Product Image</span>
                  <input type='file' name='file' />
               </div>
               <div class="file-path-wrapper">
                  <input class="file-path " placeholder="upload your image" type="text" />
               </div>
               <button type="submit" name="but_upload" class="btn btn-primary float-right" >SUBMIT</button>
            </div>
         </div>
      </form>
		 </div>
	  </div>
   </div>
</div>
<!-- /.container-fluid -->
<?php include('footer.php')?>