<?php 
include('header.php');
include('db.php');
if(isset($_SESSION['ROLE'])){
	if($_SESSION['ROLE'] == 3){
		header('location:index.php');
		die();;
	}
}
?>
<div class="container-fluid">
   <!-- DataTables Example -->
   <div class="card mb-3">
	  <div class="card-header">
	  <i class="fa fa-shopping-cart"  aria-hidden="true"></i>
		<h3>AIT Placed Orders</h3> 
	  </div>
	  <div class="card-body">
		 <div class="table-responsive">
			<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
			   <thead>
				  <tr>
				  	<th>No</th>
				  	<th>Date & Time</th>
					 <th>Customer Name</th>
					 <th>Phone</th>
					 <th>Product Name</th>
					 <th>Product ID</th>
					 <th>Delivery Address</th>
					 <th>Product Price</th>
				  </tr>
			   </thead>
			   <tfoot>
				  <!-- <tr>
				  	 <th>Date & Time</th>
					 <th>Customer Name</th>
					 <th>Phone</th>
					 <th>Product Name</th>
					 <th>Product ID</th>
					 <th>Delivery Address</th>
					 <th>Product Price</th>
				  </tr> -->
			   </tfoot>
			   <tbody>
				<?php
					$sql = "SELECT * FROM earn_marketplace_user ORDER BY id  ";
					$result = $con->query($sql);
					if ($result->num_rows > 0) {
					  while($row = $result->fetch_assoc()) {


				?>
				  <tr>
				  	 <td><?php echo $row['id']; ?></td>
					 <td><?php echo $row['datetime']; ?></td>
					 <td><?php echo $row['name']; ?></td>
					 <td><?php echo $row['phone']; ?></td>
					 <td><?php echo $row['product_name']; ?></td>
					 <td><?php echo $row['product_id']; ?></td>
					 <td><?php echo $row['address']; ?></td>
					 <td><?php echo $row['product_price']; ?></td>
				  </tr>

				  <?php
						}
					}
				  ?>
			   </tbody>
			</table>
		 </div>
	  </div>
   </div>
</div>
<?php include('footer.php')?>