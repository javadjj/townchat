<?php
session_start();

if(!isset($_SESSION['IS_LOGIN'])){
   
	header('location:login.php');
	die();
}
?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <title>Admin</title>
      <!-- Custom fonts for this template-->
      <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
      <!-- Page level plugin CSS-->
      <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
      <!-- Custom styles for this template-->
      <link href="css/sb-admin.css" rel="stylesheet">
      <!-- my custom css -->
      <link rel="stylesheet" href="css/materialize.css" />
      <link rel="stylesheet" href="css/materialize.min.css" />
      <link rel="stylesheet" href="css/business_register.css" />
      <link href="css/my-css.css" rel="stylesheet">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
      <script src="https://kit.fontawesome.com/46462c3eb9.js" crossorigin="anonymous"></script>
   </head>
   <body id="page-top">
      <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
         <a class="navbar-brand ml-5"><h1>A I T</h1></a>
         <div class="d-none d-md-inline-block ml-auto"></div>
         <!-- Navbar -->
         <ul class="navbar-nav ml-auto ml-md-0">
            <li class="nav-item dropdown no-arrow">
               <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
               <i class="fas fa-user-circle fa-fw"></i>
               </a>
               <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
                  <a class="dropdown-item" href="logout.php">Logout</a>
               </div>
            </li>
         </ul>
      </nav>
      <div id="wrapper">
         <!-- Sidebar -->
         <ul class="sidebar navbar-nav">
           
			<li class="nav-item">
               <a class="nav-link" href="index.php">
               <i class="fas fa-fw fa-tachometer-alt text-white menu-list"></i>
               <span class="text-white menu-list">Dashboard</span>
               </a>
            </li>
            <?php if($_SESSION['ROLE']==1){?>
            <li class="nav-item">
               <a class="nav-link" href="ait_products_request.php">
               <i class="fa fa-list text-white menu-list" aria-hidden="true"></i>
               <span class="text-white menu-list">Product Requests</span></a>
            </li>
            <li class="nav-item">
               <a class="nav-link" href="ait_video_requests.php">
               <i class="fa fa-list text-white menu-list" aria-hidden="true"></i>
               <span class="text-white menu-list">Videos Requests</span></a>
            </li>
             <li class="nav-item">
               <a class="nav-link" href="live_videos.php">
               <i class="fa fa-video-camera text-white" aria-hidden="true"></i>
               <span class="text-white menu-list">Live Videos</span></a>
            </li>
            <li class="nav-item">
               <a class="nav-link" href="live_products.php">
               <i class="fa fa-list text-white menu-list" aria-hidden="true"></i>
               <span class="text-white menu-list">Live Products</span></a>
            </li>
            <?php } ?>
            <?php if($_SESSION['ROLE']==2 || $_SESSION['ROLE']==1){?>
            <li class="nav-item">
               <a class="nav-link" href="marketplace_ordrs.php">
               <i class="fa fa-shopping-cart text-white menu-list"  aria-hidden="true"></i>
               <span class="text-white menu-list">Marketplace Orders</span></a>
            </li>
         <li class="nav-item">
               <a class="nav-link" href="ait_product_upload.php">
               <i class="fa fa-upload text-white menu-list" aria-hidden="true"></i>
               <span class="text-white menu-list">Product Upload</span></a>
            </li>
            <?php } ?>
            <?php if($_SESSION['ROLE']==3 || $_SESSION['ROLE']==1){?>
            <li class="nav-item">
               <a class="nav-link" href="ait_video_upload.php">
               <i class="fa fa-upload text-white menu-list" aria-hidden="true"></i>
               <span class="text-white menu-list">Video Upload</span></a>
            </li>
            <?php } ?>
         </ul>
         <div id="content-wrapper">

         