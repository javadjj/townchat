<?php
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "townchat";
$con = mysqli_connect($servername, $username, $password, $dbname) or 
die("Connection failed: " . mysqli_connect_error());
 
if(isset($_POST['but_upload'])){
   
   $maxsize = 5242880;

   if(isset($_POST ['businessname'])){
      $errors= array();
      $businessName =$_POST ['businessname'];
      $whatsapp_number = $_POST['whatsapp_number'];
	   $budjet =$_POST ['budjet'];
      $latitude =$_POST ['latitude'];
      $longitude =$_POST ['longitude'];
      $question1 =$con -> real_escape_string($_POST ['question1']);
      $question1answer =$con -> real_escape_string($_POST ['question1answer']);
      $question1_option1 =$_POST ['question1_option1'];
      $question1_option2 =$_POST ['question1_option2'];
      $question2 =$con -> real_escape_string($_POST ['question2']);
      $question2_answer = $_POST['question2_answer'];
      $question2_option1 = $_POST['question2_option1'];
      $question2_option2 = $_POST['question2_option2'];
       $name=$_FILES["file"]["name"];
       $target_dir ="ait_videos/";
       $target_file =$target_dir .$_FILES["file"]["name"];
       $extension = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
       $extensions_arr = array("mp4");

       if( in_array($extension,$extensions_arr) ){
       
             if(($_FILES['file']['size'] >= $maxsize) || ($_FILES["file"]["size"] == 0)) {
              
                $_SESSION['uploadmessage'] = "File too large. File must be less than 1MB.";
           }
          else{
              if(move_uploaded_file($_FILES['file']['tmp_name'],$target_file)){              

              mysqli_query( $con,"INSERT INTO earn_bss_rgstr (businessName,phone,budjet,question1,question1_answer,question1_option1,question1_option2,question2,question2_answer,question2_option1,question2_option2,name,video_url,latitude,longitude) 
              VALUES ('$businessName','$whatsapp_number','$budjet','$question1','$question1answer','$question1_option1','$question1_option2','$question2','$question2_answer','$question2_option1','$question2_option2','$name','$target_file','$latitude','$longitude')") or die(mysqli_error($con));
              }else{
               echo "<script type='text/javascript'>alert('Successfully Registered')</script>";
              }
         }
       }else{
          $_SESSION['uploadmessage'] = "Invalid file extension.";
       }
   }else{
       $_SESSION['uploadmessage'] = "Please select a file.";
       print_r($_FILES);
   }
}

?>


<!DOCTYPE html>
<html>
   <meta name="viewport" content="width=device-width, initial-scale=1.0" />
   <title>Register Your Business</title>
   <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet" />
   <link rel="stylesheet" href="css/materialize.css" />
   <link rel="stylesheet" href="css/materialize.min.css" />
   <link rel="stylesheet" href="css/business_register.css" />
   <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous" /> -->
   <body>
      <form id="regForm" action="" method="POST" enctype="multipart/form-data">
         <h4>Register Your Business</h4>
         <!-- One "tab" for each step in the form: -->
         <div class="tab">
            <div class="input-field col s12">
               <input id="business_name" name="businessname" type="text" class="validate" />
               <label for="business_name">Business Name</label>
            </div>
            <div class="input-field col s12">
               <input id="whatsappnumber" value="91" name="whatsapp_number" type="tel" minlength="12" data-length="12" class="validate" />
               <label for="whatsappnumber">WhatsApp Number</label>
            </div>
            <div class="input-field col s12">
               <input id="budjet" type="number" name="budjet" class="validate" />
               
               <label for="budjet">Budjet</label>
            </div>
            <div class="row">
               <div class="input-field col s6">
                  <input id="latitude" type="text" name="latitude" class="validate" />
                  <label for="latitude">Latitude</label>
               </div>
               <div class="input-field col s6">
                  <input id="longitude" type="text" name="longitude" class="validate" />
                  <label for="longitude">Longitude</label>
               </div>
            </div>
            <div class="file-field input-field">
               <div class="btn card-panel teal lighten-2">
                  <span class="white-text">Video</span>
                  <input type='file' name='file' />
               </div>
               <div class="file-path-wrapper">
                  <input class="file-path " placeholder="upload your video" type="text" />
               </div>
            </div>
         </div>
         <div class="">
            Video Related Question 1
            <div class="input-field col s12">
               <input id="question_1" type="text" name="question1" class="validate" />
               <label for="question_1">Question One</label>
            </div>
            <div class="input-field col s12">
               <input id="right_answer1" type="text" name="question1answer" class="validate" />
               <label for="right_answer1">Right Answer</label>
            </div>
            <div class="row">
               <div class="input-field col s6">
                  <input id="q_1option_1" type="text" name="question1_option1" class="validate" />
                  <label for="q_1option_1">Option 1</label>
               </div>
               <div class="input-field col s6">
                  <input id="q_1option_2" type="text" name="question1_option2" class="validate" />
                  <label for="q_1option_2">ption 2</label>
               </div>
            </div>
         </div>
         <div class="">
            Video Related Question 2
            <div class="input-field col s12">
               <input id="question_2" type="text" name="question2" class="validate" />
               <label for="question_2">Question Two</label>
            </div>
            <div class="input-field col s12">
               <input id="right_answer2" type="text" name="question2_answer" class="validate" />
               <label for="right_answer2">Right Answer</label>
            </div>
            <div class="row">
               <div class="input-field col s6">
                  <input id="q_2option_1" type="text" name="question2_option1" class="validate" />
                  <label for="q_2option_1">Option 1</label>
               </div>
               <div class="input-field col s6">
                  <input id="q_2option_2" type="text" name="question2_option2" class="validate" />
                  <label for="q_2option_2">ption 2</label>
               </div>
               <button type="submit" name="but_upload" >SUBMIT</button>
            </div>
         </div>
         <?php 
            if(isset($_SESSION['uploadmessage'])){
            echo $_SESSION['uploadmessage'];
            unset($_SESSION['uploadmessage']);
            }
            ?>
         <div style="overflow: auto;padding:10px 10px 15px 10px;">
            <div style="">
               <button type="button" style="float:left;" id="prevBtn" class="btn bg-light btn-small" onclick="nextPrev(-1)"><i class="fa-solid fa-chevron-left"></i></button>
               <button type="button" style="float: right;" class="btn btn-primary btn-small" id="nextBtn" onclick="nextPrev(1)">Next</button>
            </div>
         </div>
         <!-- Circles which indicates the steps of the form: -->
         <div style="text-align: center; margin-top: 10px; display:none">
            <span class="step"></span>
            <span class="step"></span>
         </div>
      </form>

      <script src="https://kit.fontawesome.com/46462c3eb9.js" crossorigin="anonymous"></script>
      <script src="js/materialize.js"></script>
      <script src="js/materialize.min.js"></script>
      <script src="js/business_register.js"></script>
      <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script> -->
   </body>
</html>
